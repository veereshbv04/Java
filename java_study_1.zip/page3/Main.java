class Main {
  public static void main(String[] args) {
    // Print 17 as an integer
    System.out.println(17);
    
    // Print the sum of 5 and 3
    System.out.println(5+3);
    
    // Print "5 + 3" as a string
    System.out.println(" 5 +3 ");
    
  }
}
