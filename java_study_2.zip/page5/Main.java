class Main {
  public static void main(String[] args) {
    int number = 12;
    
    // Add else and else if statements
    if (number < 10) {
      System.out.println("The number is less than 10");
    }
    else if(number< 20){
      System.out.println("The number is equal to or greater than 10, but less than 20");
    }
    else{
      System.out.println("The number is equal to or greater than 20");
    }
    
  }
}