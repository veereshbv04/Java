class Main {
  public static void main(String[] args) {
    String[] names = {"Bob", "Kate", "John"};
    
    // Get the elements of names using a for loop, and print "My name is ____"
    for(int i=0;i<names.length;i++){
      System.out.println("My name is " + names[i]);
    }
  }
}