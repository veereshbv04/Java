class Main {
  public static void main(String[] args) {
    int number1 = 7;
    int number2 = 2;
    System.out.println(number1 / number2);
    
    // Cast number1 to a double, divide it by number2, and print it
    System.out.println((double)number1/number2);
    
  }
}
