class Main {
  public static void main(String[] args) {
    // Create a for loop that runs 10 times
    for(int i=1;i<=10;i++){
      System.out.println("Loop count: " + i);
    }
    
  }
}