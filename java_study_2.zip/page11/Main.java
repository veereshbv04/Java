class Main {
  public static void main(String[] args) {
    // Assign a list of names to the names variable
    String[] names ={"Ken","Master White","Ben"};
    
    // Print the element at index 0
    System.out.println(names[0]);
    
    // Print the element at index 2 
    System.out.println(names[2]);
    
  }
}
