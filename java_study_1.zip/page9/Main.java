class Main {
  public static void main(String[] args) {
    int number = 3;
    System.out.println(number);
    
    // Update the number variable by adding 7 to it
    number +=7;
    
    // Print the number variable
    System.out.println(number);
      
  }
}
