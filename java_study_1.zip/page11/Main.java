class Main {
  public static void main(String[] args) {
    int length = 6;
    int height = 8;
    
    // Declare the rectangleArea variable of type int, and assign the area of the rectangle to it. 
    int rectangleArea=length * height;
    
    // Print the rectangleArea variable
    System.out.println(rectangleArea);
    
    // Declare the triangleArea variable of type int, and assign the area of the triangle to it. 
    int triangleArea=length * height / 2;
    
    // Print the triangleArea variable 
    System.out.println(triangleArea);
    
  }
}

