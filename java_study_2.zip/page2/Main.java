class Main {
  public static void main(String[] args) {
    // Compare 8 and 5 with < or > to print false
    System.out.println(8<5);
    
    // Compare 3 and 2 with <= or >= to print true
    System.out.println(3>=2);
    
  }
}

