class Main {
  public static void main(String[] args) {
    // Put true as the condition for the if statement
    if (true) {
      System.out.println("The condition is true. Printing...");
    }
    
    // Put false as the condition for the if statement
    if (false) {
      System.out.println("The condition is false. Not printing...");
    }
    
    int x = 5;
    // If x is greater than 2, print "x is greater than 2"
    if (x > 2){
      System.out.println("x is greater than 2");
    }
   
    
    
    // If x is greater than 8, print"x is greater than 2"
     if (x > 8){
      System.out.println("x is greater than 8");
    }
    
    
  }
}